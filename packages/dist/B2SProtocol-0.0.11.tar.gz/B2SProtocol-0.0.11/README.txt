===========
B2SProtocol
===========

Packages to define backtoshops protocol between servers
