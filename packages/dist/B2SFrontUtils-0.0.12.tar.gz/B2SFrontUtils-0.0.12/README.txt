===========
B2SProtocol
===========

Packages to define api access and redis cache proxy used by front servers
