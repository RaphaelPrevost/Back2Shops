=========
B2SRespUtils
=========

Packages to provide some utils functions to generate response

