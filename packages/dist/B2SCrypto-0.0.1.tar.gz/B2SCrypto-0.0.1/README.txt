=========
B2SCrypto
=========

Packages to encrypt backtoshop request, and decrypt backtoshops response

