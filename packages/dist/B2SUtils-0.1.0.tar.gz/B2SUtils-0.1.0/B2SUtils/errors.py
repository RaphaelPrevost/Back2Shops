class DatabaseError(Exception):
    pass

class ValidationError(Exception):
    pass

