from enum import Enum

class SERVICES(Enum):
    USR = 'USR'
    ADM = 'ADM'
    FIN = 'FIN'
    AST = 'AST'
    FRO = 'FRO'
